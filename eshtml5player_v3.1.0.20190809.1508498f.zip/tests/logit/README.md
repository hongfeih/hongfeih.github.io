# Introduction #
Use to capture log of HTML5 Player for long running test.

## Start log server ##
- cd log_server
- npm install
- node index.js

## How to use #
- Change LOG_SERVER to "http://x.x.x.x:8582/" in index.html
- Open http://localhost:8000/tests/logit

