/**
 * Created by Logan on 2017/4/25.
 */
(function () {
    window['shakacopy'] = {};
    window['hlsjscopy'] = {};
    window['shakacopy'] = jQuery.extend(true, {}, window['shaka']);
    window['hlsjscopy'] = window['Hls'];
})();
